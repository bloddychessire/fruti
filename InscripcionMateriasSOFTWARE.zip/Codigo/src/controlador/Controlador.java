package controlador;

import mundo.Sistema;

import java.util.ArrayList;
import java.util.List;

public class Controlador {
    private Sistema sistema;

    public Controlador() {
        sistema = Sistema.getInstancia();
    }

    public List<String> listarMaterias(String carrera) {
        return sistema.getMaterias(carrera);
    }

    public String asignarHorario() {
        return sistema.asignarHorario();
    }

    public boolean validarInscripcion(List<String> materiasSeleccionadas) {
        return !materiasSeleccionadas.isEmpty();
    }
}
